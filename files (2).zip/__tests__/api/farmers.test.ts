import { createMocks } from 'node-mocks-http';
import handler from '../../pages/api/farmers/index';

describe('Farmers API', () => {
  it('GET - returns array of farmers', async () => {
    const { req, res } = createMocks({ method: 'GET' });
    await handler(req, res);
    expect(res._getStatusCode()).toBe(200);
    const data = JSON.parse(res._getData());
    expect(Array.isArray(data)).toBe(true);
  });
});