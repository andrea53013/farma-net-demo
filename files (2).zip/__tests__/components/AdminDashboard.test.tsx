import { render, screen } from '@testing-library/react';
import AdminDashboard from '../../pages/admin/dashboard';

test('renders farmer table', () => {
  render(<AdminDashboard farmers={[{id: '1', farmName: 'GreenFarm', varieties: ['Trigo'] }]} labs={[]} />);
  expect(screen.getByText('GreenFarm')).toBeInTheDocument();
});