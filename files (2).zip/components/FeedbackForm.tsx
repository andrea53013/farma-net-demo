import { useState } from 'react';
export default function FeedbackForm() {
  const [message, setMessage] = useState('');
  const submit = async () => {
    await fetch('/api/feedback', {
      method: 'POST',
      body: JSON.stringify({ message }),
      headers: { 'Content-Type': 'application/json' }
    });
    setMessage('');
    alert('Feedback dërguar!');
  };
  return (
    <div>
      <textarea value={message} onChange={e => setMessage(e.target.value)} />
      <button onClick={submit}>Dërgo Feedback</button>
    </div>
  );
}