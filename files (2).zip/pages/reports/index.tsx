import { CSVLink } from 'react-csv';
import { BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

export default function Reports({ data }) {
  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">Raporti Agronomik</h1>
      <BarChart width={600} height={300} data={data}>
        <XAxis dataKey="variety" />
        <YAxis />
        <Tooltip />
        <Bar dataKey="count" fill="#4F46E5" />
      </BarChart>
      <CSVLink data={data} filename="export-report.csv">Shkarko CSV</CSVLink>
    </div>
  );
}