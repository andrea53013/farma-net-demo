import { NextApiRequest, NextApiResponse } from 'next';
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    // ruaj të dhëna sensorësh
    res.status(201).json({ ok: true });
  } else {
    res.status(405).end();
  }
}