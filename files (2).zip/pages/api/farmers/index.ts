import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../lib/prisma';
import { withRole } from '../../../lib/withRole';

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method === 'GET') {
    const farmers = await prisma.farmer.findMany({ include: { user: true } });
    return res.json(farmers);
  }
  if (req.method === 'POST') {
    const { userId, farmName, varieties } = req.body;
    const farmer = await prisma.farmer.create({ data: { userId, farmName, varieties } });
    return res.status(201).json(farmer);
  }
  res.status(405).end();
};

export default withRole('ADMIN', handler);