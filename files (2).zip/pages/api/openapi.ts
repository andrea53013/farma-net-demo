import { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  res.json({
    openapi: '3.0.0',
    info: { title: 'Agropilot-Net API', version: '1.0.0' },
    paths: {
      '/api/farmers': {
        get: { summary: 'Listo fermerët', responses: { '200': { description: 'OK' } } },
        post: { summary: 'Krijo fermer', responses: { '201': { description: 'Created' } } },
      },
      // Shto endpoint-et e tjera sipas strukturës
    },
  });
}