import { GetServerSideProps } from 'next';
import { getSession } from 'next-auth/react';
import prisma from '../../lib/prisma';

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const session = await getSession(ctx);
  if (!session || session.user.role !== 'ADMIN') {
    return { redirect: { destination: '/api/auth/signin', permanent: false } };
  }
  const farmers = await prisma.farmer.findMany();
  const labs = await prisma.laboratory.findMany();
  // ... eksportues, institucione
  return { props: { farmers, labs } };
};

export default function AdminDashboard({ farmers, labs }) {
  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">Admin Dashboard</h1>
      <section className="mb-8">
        <h2 className="text-xl">Fermerët</h2>
        <table className="w-full table-auto">
          <thead><tr><th>Emri Fermer</th><th>Varietetet</th></tr></thead>
          <tbody>
            {farmers.map(f => (
              <tr key={f.id}>
                <td>{f.farmName}</td>
                <td>{f.varieties.join(', ')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      {/* Sekcione për laborator, eksportues, institucione */}
    </div>
  );
}