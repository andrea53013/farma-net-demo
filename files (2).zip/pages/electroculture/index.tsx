import { useState } from 'react';

export default function Electro() {
  const [message, setMessage] = useState('');
  const submit = async () => {
    await fetch('/api/feedback', {
      method: 'POST',
      body: JSON.stringify({ contentId: '1', message }),
      headers: { 'Content-Type': 'application/json' },
    });
    alert('Feedback dërguar');
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">Elektrokultura</h1>
      <video src="/electro-guide.mp4" controls className="w-full mb-4" />
      <textarea
        className="w-full p-2 border"
        rows={4}
        value={message}
        onChange={e => setMessage(e.target.value)}
      />
      <button onClick={submit} className="mt-2 px-4 py-2 bg-blue-600 text-white">Dërgo Feedback</button>
    </div>
  );
}