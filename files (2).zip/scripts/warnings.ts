import cron from 'node-cron';
import prisma from '../lib/prisma';
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({ /* SMTP config */ });

cron.schedule('0 8 * * *', async () => {
  const missingDocs = await prisma.farmer.findMany({ where: { /* logjikë mungese dokumenti */ } });
  for (const f of missingDocs) {
    await transporter.sendMail({
      to: f.user.email,
      subject: 'Paralajmërim: Dokumenti mungon',
      text: `Përshëndetje ${f.user.name}, ju mungon dokumenti...`,
    });
  }
});