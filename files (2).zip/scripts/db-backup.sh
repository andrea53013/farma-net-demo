#!/bin/bash
PGPASSWORD="$PGPASSWORD" pg_dump -h $PGHOST -U $PGUSER $PGDATABASE > backup_$(date +%F).sql