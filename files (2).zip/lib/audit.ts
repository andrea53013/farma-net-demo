import prisma from './prisma';

export async function logAudit(entity: string, entityId: string, action: string, performedBy: string) {
  await prisma.auditLog.create({
    data: { entity, entityId, action, performedBy },
  });
}