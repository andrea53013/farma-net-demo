# Udhëzues për Admin

## Instalimi
1. Deploy platformën në Vercel.
2. Shto variabla ambienti: DATABASE_URL, NEXTAUTH_SECRET, SMTP_*.

## Menaxhimi i përdoruesve
- Shto/hiq përdorues nga dashboard-i.
- Shiko audit-trail për çdo veprim.

## Raportimi & Audit Trail
- Eksporto log veprime si CSV.
- Shiko raportet mujore.